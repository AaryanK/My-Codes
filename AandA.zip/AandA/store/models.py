from django.db import models
from django.contrib.auth.models import User
from django.db.models.base import Model

# Create your models here.


class Admin(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    image = models.ImageField(default="dashboard/7.png")




class Category(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class Product(models.Model):
    RATINGS = (
    (0, 0),
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    )

    name = models.CharField(max_length=200)
    price = models.IntegerField()
    available_number = models.IntegerField()
    category = models.ForeignKey(Category,on_delete=models.SET_NULL,null=True)
    ratings = models.IntegerField(default=0,choices=RATINGS)


    def __str__(self):
        return self.name
